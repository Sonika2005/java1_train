package Assignmentt3;

class Person {
    int age;
    String name;

    Person(int age, String name) {
        this.age = age;
        this.name = name;
    }

    @Override
    public String toString() {
        return "(" + age + ", " + name + ")";
    }
}

public class StabilityDemo {

    // Bubble Sort (Stable)
    public static void bubbleSort(Person[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].age > arr[j + 1].age) {
                    Person temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Selection Sort (Unstable)
    public static void selectionSort(Person[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].age < arr[minIdx].age) {
                    minIdx = j;
                }
            }
            Person temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;
        }
    }

    public static void printArray(Person[] arr) {
        for (Person p : arr) {
            System.out.print(p + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Person[] people1 = {
                new Person(25, "Alice"),
                new Person(20, "Bob"),
                new Person(20, "Charlie"),
                new Person(30, "David")
        };

        Person[] people2 = {
                new Person(25, "Alice"),
                new Person(20, "Bob"),
                new Person(20, "Charlie"),
                new Person(30, "David")
        };

        System.out.println("Original Array:");
        printArray(people1);

        bubbleSort(people1);
        System.out.println("\nAfter Bubble Sort (Stable):");
        printArray(people1);

        selectionSort(people2);
        System.out.println("\nAfter Selection Sort (Unstable):");
        printArray(people2);
    }
}